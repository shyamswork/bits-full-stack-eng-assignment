// src/components/BookList.js
import React from "react";

const BookList = ({ books }) => {
  return (
    <div>
      <h3>Your Book List</h3>
      {books.length === 0 ? (
        <p>No books listed yet.</p>
      ) : (
        <ul>
          {books.map((book) => (
            <li key={book._id}>
              <strong>{book.title}</strong> by {book.author} ({book.genre})
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default BookList;
