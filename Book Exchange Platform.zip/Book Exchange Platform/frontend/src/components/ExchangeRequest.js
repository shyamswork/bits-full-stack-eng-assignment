// src/components/ExchangeRequest.js
import React, { useState, useEffect } from "react";
import { useParams, useHistory } from "react-router-dom";
import api from "../api";

const ExchangeRequest = () => {
  const { bookId } = useParams(); // Get the bookId from the URL
  const history = useHistory();
  const [bookDetails, setBookDetails] = useState(null); // Store book details
  const [deliveryMethod, setDeliveryMethod] = useState("");
  const [exchangeDuration, setExchangeDuration] = useState(7); // Default to 7 days
  const [message, setMessage] = useState(""); // Optional message for exchange
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    // Check if token exists, if not redirect to login
    const token = localStorage.getItem("token");
    if (!token) {
      history.push("/login");
      return;
    }

    // Fetch book details using the bookId
    const fetchBookDetails = async () => {
      try {
        const response = await api.get(`/books/${bookId}`); // Fetch book details from backend
        setBookDetails(response.data);
      } catch (err) {
        console.error("Error fetching book details:", err);
        setError("Failed to load book details.");
      }
    };

    fetchBookDetails();
  }, [bookId, history]);

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!deliveryMethod || !exchangeDuration) {
      setError("Please fill out all fields.");
      return;
    }

    try {
      const token = localStorage.getItem("token");
      if (!token) {
        setError("You must be logged in to send an exchange request.");
        return;
      }

      const exchangeRequest = {
        bookId,
        deliveryMethod,
        exchangeDuration,
        message,
      };

      // Send exchange request to backend
      await api.post("/exchange-request", exchangeRequest, {
        headers: {
          Authorization: `Bearer ${token}`, // Add the JWT token to headers
        },
      });

      setSuccess("Exchange request sent successfully!");
      setError("");
    } catch (err) {
      console.error("Error sending exchange request:", err);
      setError("Failed to send exchange request. Please try again.");
      setSuccess("");
    }
  };

  return (
    <div>
      <h3>Exchange Request for "{bookDetails ? bookDetails.title : "Loading..."}"</h3>
      {error && <p style={{ color: "red" }}>{error}</p>}
      {success && <p style={{ color: "green" }}>{success}</p>}

      <form onSubmit={handleSubmit}>
        <div>
          <label>Delivery Method:</label>
          <input
            type="text"
            value={deliveryMethod}
            onChange={(e) => setDeliveryMethod(e.target.value)}
            placeholder="e.g. Mail, Pickup, etc."
            required
          />
        </div>

        <div>
          <label>Exchange Duration (days):</label>
          <input
            type="number"
            value={exchangeDuration}
            onChange={(e) => setExchangeDuration(e.target.value)}
            min="1"
            max="30"
            required
          />
        </div>

        <div>
          <label>Additional Message (optional):</label>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Add any additional notes for the exchange."
          />
        </div>

        <button type="submit">Send Exchange Request</button>
      </form>
    </div>
  );
};

export default ExchangeRequest;
