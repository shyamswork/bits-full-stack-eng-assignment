// src/components/TransactionHistory.js
import React, { useState, useEffect } from "react";
import api from "../api";
import { useHistory } from "react-router-dom";

const TransactionHistory = () => {
  const [transactions, setTransactions] = useState([]);
  const [error, setError] = useState("");
  const history = useHistory();

  useEffect(() => {
    const fetchTransactions = async () => {
      const token = localStorage.getItem("token");
      if (!token) {
        history.push("/login");
        return;
      }

      try {
        const response = await api.get("/transactions", {
          headers: {
            Authorization: `Bearer ${token}`, // Attach token for authentication
          },
        });
        setTransactions(response.data);
      } catch (err) {
        console.error("Error fetching transactions:", err);
        setError("Failed to load transactions. Please try again.");
      }
    };

    fetchTransactions();
  }, [history]);

  return (
    <div>
      <h3>Transaction History</h3>
      {error && <p style={{ color: "red" }}>{error}</p>}
      
      {transactions.length === 0 ? (
        <p>No transactions found.</p>
      ) : (
        <ul>
          {transactions.map((transaction) => (
            <li key={transaction._id}>
              <h4>{transaction.bookTitle}</h4>
              <p>Status: {transaction.status}</p>
              <p>Delivery Method: {transaction.deliveryMethod}</p>
              <p>Exchange Duration: {transaction.exchangeDuration} days</p>
              <p>Message: {transaction.message || "No additional notes"}</p>
              <p>Date: {new Date(transaction.createdAt).toLocaleDateString()}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default TransactionHistory;
