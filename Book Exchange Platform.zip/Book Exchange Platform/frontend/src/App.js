// src/App.js
import React from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import LoginPage from "./pages/LoginPage";
import SignupPage from "./pages/SignupPage";
import DashboardPage from "./pages/DashboardPage";
import { AuthContext } from "./context/AuthContext";
import { useContext } from "react";
import ExchangeRequest from "./components/ExchangeRequest";
import TransactionHistory from "./components/TransactionHistory";

const App = () => {
  const { authState } = useContext(AuthContext);

  return (
    <Router>
      <Switch>
        <Route path="/login" component={LoginPage} />
        <Route path="/signup" component={SignupPage} />
        <Route path="/dashboard">
          {authState.isAuthenticated ? <DashboardPage /> : <LoginPage />}
        </Route>
        <Route path="/exchange-request/:bookId">
          {authState.isAuthenticated ? <ExchangeRequest /> : <LoginPage />}
        </Route>
        <Route path="/transaction-history">
          {authState.isAuthenticated ? <TransactionHistory /> : <LoginPage />}
        </Route>
        <Route path="/" exact component={LoginPage} />
      </Switch>
    </Router>
  );
};

export default App;
