// src/pages/DashboardPage.js
import React, { useState, useEffect } from "react";
import { useHistory } from "react-router-dom";
import api from "../api";
import BookForm from "../components/BookForm";
import BookList from "../components/BookList";

const DashboardPage = () => {
  const [books, setBooks] = useState([]);
  const history = useHistory();

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const response = await api.get("/books/user");
        setBooks(response.data);
      } catch (error) {
        console.log("Error fetching books:", error);
      }
    };

    if (!localStorage.getItem("token")) {
      history.push("/login"); // Redirect to login if no token
    }

    fetchBooks();
  }, [history]);

  const handleLogout = () => {
    localStorage.removeItem("token"); // Remove token from localStorage
    history.push("/login"); // Redirect to login
  };

  return (
    <div>
      <h2>Dashboard</h2>
      <button onClick={handleLogout}>Logout</button>
      <BookForm />
      <BookList books={books} />
    </div>
  );
};

export default DashboardPage;
