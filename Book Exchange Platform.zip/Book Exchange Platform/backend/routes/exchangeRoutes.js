const express = require("express");
const ExchangeRequest = require("../models/ExchangeRequest");

const router = express.Router();

// Send an exchange request
router.post("/", async (req, res) => {
  const { senderId, receiverId, bookId } = req.body;
  
  const exchangeRequest = new ExchangeRequest({
    senderId,
    receiverId,
    bookId,
  });
  
  await exchangeRequest.save();
  res.status(201).send("Exchange request sent.");
});

// Accept/Reject/Modify request
router.put("/:id", async (req, res) => {
  const { status } = req.body;
  const request = await ExchangeRequest.findByIdAndUpdate(req.params.id, { status }, { new: true });
  
  res.json(request);
});

module.exports = router;
