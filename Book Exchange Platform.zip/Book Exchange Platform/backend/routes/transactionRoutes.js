const express = require("express");
const Transaction = require("../models/Transaction");

const router = express.Router();

// Record a transaction
router.post("/", async (req, res) => {
  const { bookId, senderId, receiverId } = req.body;
  
  const transaction = new Transaction({
    bookId,
    senderId,
    receiverId,
    status: "completed",
  });
  
  await transaction.save();
  res.status(201).send("Transaction completed.");
});

// Get all transactions for a user
router.get("/user/:userId", async (req, res) => {
  const transactions = await Transaction.find({ $or: [{ senderId: req.params.userId }, { receiverId: req.params.userId }] });
  res.json(transactions);
});

module.exports = router;
