const express = require("express");
const { register, login, forgotPassword } = require("../controllers/authController");
const { protect } = require("../middleware/authMiddleware");

const router = express.Router();

// Public routes
router.post("/signup", register);
router.post("/login", login);
router.post("/forgot-password", forgotPassword);

// Protected routes
router.get("/profile", protect, (req, res) => {
  // This route is protected, and only accessible with a valid token
  res.send("This is a protected route. User ID: " + req.user);
});

module.exports = router;
