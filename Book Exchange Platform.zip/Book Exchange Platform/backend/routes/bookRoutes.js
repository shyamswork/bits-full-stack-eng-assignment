const express = require("express");
const { protect } = require("../middleware/authMiddleware");
const Book = require("../models/Book");

const router = express.Router();

// Add a book (protected route)
router.post("/", protect, async (req, res) => {
  const { title, author, genre, condition, availability } = req.body;

  const newBook = new Book({
    title,
    author,
    genre,
    condition,
    availability,
    userId: req.user, // Use the userId from the JWT token
  });

  try {
    await newBook.save();
    res.status(201).send("Book added successfully.");
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
});

// Get all books for the authenticated user
router.get("/user", protect, async (req, res) => {
  try {
    const books = await Book.find({ userId: req.user });
    res.json(books);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error" });
  }
});

module.exports = router;
