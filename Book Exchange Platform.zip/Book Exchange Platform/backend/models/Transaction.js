// models/Transaction.js
const mongoose = require('mongoose');

// Transaction Schema
const transactionSchema = new mongoose.Schema(
  {
    exchangeRequestId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'ExchangeRequest',
      required: true,
    },
    transactionStatus: {
      type: String,
      enum: ['Completed', 'Failed'],
      default: 'Completed',
    },
    transactionDate: {
      type: Date,
      default: Date.now,
    },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Transaction', transactionSchema);
