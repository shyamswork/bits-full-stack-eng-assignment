// controllers/transactionController.js
const Transaction = require('../models/Transaction');
const ExchangeRequest = require('../models/ExchangeRequest');

// Complete the exchange and create a transaction record
const completeExchange = async (req, res) => {
  const { exchangeRequestId } = req.body;

  try {
    const exchangeRequest = await ExchangeRequest.findById(exchangeRequestId);
    if (!exchangeRequest) {
      return res.status(404).json({ message: 'Exchange request not found' });
    }

    if (exchangeRequest.status !== 'Accepted') {
      return res.status(400).json({ message: 'Exchange not accepted' });
    }

    const transaction = new Transaction({
      exchangeRequestId: exchangeRequest._id,
      transactionStatus: 'Completed',
    });

    await transaction.save();
    res.status(201).json(transaction);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get all transactions
const getTransactions = async (req, res) => {
  try {
    const transactions = await Transaction.find();
    res.json(transactions);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { completeExchange, getTransactions };
