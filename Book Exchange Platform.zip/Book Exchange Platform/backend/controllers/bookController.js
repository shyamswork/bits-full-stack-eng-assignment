// controllers/bookController.js
const Book = require('../models/Book');
const User = require('../models/User');

// Add a new book
const addBook = async (req, res) => {
  const { title, author, genre, condition, availability } = req.body;

  try {
    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const book = new Book({
      title,
      author,
      genre,
      condition,
      availability,
      user: req.user.id,
    });

    await book.save();
    user.books.push(book);
    await user.save();

    res.status(201).json(book);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

// Get all books listed by the user
const getUserBooks = async (req, res) => {
  try {
    const books = await Book.find({ user: req.user.id });
    res.json(books);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { addBook, getUserBooks };
